#!/bin/bash

while true; do
    if [ -d "$XDG_RUNTIME_DIR" ]; then
        /usr/bin/wl-paste --type text --watch cliphist store
        exit 0
    fi
    sleep 3
done
