#!/bin/bash

echo 1 > /dev/wmtWifi
