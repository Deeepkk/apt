#!/bin/bash
sleep 5
echo 1 > /dev/wmtWifi
